//
//  AroundCollectionViewCell.h
//  WGForSmile
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Deal.h"
@interface AroundCollectionViewCell : UICollectionViewCell

@property (nonatomic,strong) Deal * deal;
@end
