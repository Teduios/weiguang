//
//  BeginPageViewController.h
//  WGForSmile
//
//  Created by tarena on 15/10/11.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BeginPageViewController : UITabBarController

@end
