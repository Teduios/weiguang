//
//  BooksContentDataViewController.h
//  PageViewControllerDemo
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 Sumtice：http://sacrelee.me. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BooksContentDataViewController : UIViewController
@property (nonatomic,strong) NSString *index;
@property (nonatomic,strong) UIColor *backColor;
@property (nonatomic,strong) NSString* content;

@end
