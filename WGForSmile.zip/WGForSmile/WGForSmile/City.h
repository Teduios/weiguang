//
//  City.h
//  WGForSmile
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface City : NSObject

@property (nonatomic,strong) NSString * name;
@property (nonatomic,strong) NSString * pinYin;
@property (nonatomic,strong) NSString * pinYinHead;
@property (nonatomic,strong) NSArray * regions;

@end
