//
//  CityGroup.h
//  WGForSmile
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CityGroup : NSObject

@property (nonatomic,strong) NSString * title;
@property (nonatomic,strong) NSArray * cities;

@end
