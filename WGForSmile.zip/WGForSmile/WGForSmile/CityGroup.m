//
//  CityGroup.m
//  WGForSmile
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "CityGroup.h"

@implementation CityGroup

@end
