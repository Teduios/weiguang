//
//  CommunityManager.h
//  WGForSmile
//
//  Created by tarena on 15/11/14.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommunityManager : NSObject

+(NSArray*)analysisBmobObjects:(NSArray*)BmobObjectsArray;

@end
