//
//  CommunityTableViewCell.h
//  WGForSmile
//
//  Created by tarena on 15/11/14.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommunityTableViewCell : UITableViewCell

@property (nonatomic,strong) UILabel * label;
@property (nonatomic,strong) UIImageView * imageview;
@property (nonatomic,strong) UITextView * content;
@property (nonatomic,strong) UILabel* whoSend;
@end
