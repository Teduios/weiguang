//
//  DPConstants.h
//  apidemo
//
//  Created by ZhouHui on 13-1-28.
//  Copyright (c) 2013年 Dianping. All rights reserved.
//

#ifndef apidemo_DPConstants_h
#define apidemo_DPConstants_h

#define DPAPIVersion                @"2.0"

#define kDPAPIErrorDomain           @"DPAPIErrorDomain"
#define kDPAPIErrorCodeKey          @"DPAPIErrorCodeKey"

#define kDPAPIDomain				@"http://api.dianping.com/"

#endif
