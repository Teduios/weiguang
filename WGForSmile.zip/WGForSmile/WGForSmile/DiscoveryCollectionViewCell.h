//
//  DiscoveryCollectionViewCell.h
//  WGForSmile
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiscoveryCollectionViewCell : UICollectionViewCell

@property (nonatomic,strong) UILabel * label;
@property (nonatomic,strong) UIImageView * imageView;

@end
