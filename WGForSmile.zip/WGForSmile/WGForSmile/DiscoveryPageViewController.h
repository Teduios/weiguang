//
//  DiscoveryPageViewController.h
//  WGForSmile
//
//  Created by tarena on 15/11/14.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiscoveryPageViewController : UIViewController

@end
