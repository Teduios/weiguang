//
//  GameSubViewController.h
//  WGForSmile
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GameSubViewController : UIViewController
@property (nonatomic,strong) NSString * urlName;
@end
