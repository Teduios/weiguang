//
//  HomeNews.h
//  WGForSmile
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomeNews : NSObject

@property (nonatomic,strong) NSString * ctime;
@property (nonatomic,strong) NSString * title;
@property (nonatomic,strong) NSString * descript;
@property (nonatomic,strong) NSString * picUrl;
@property (nonatomic,strong) NSString * url;

@end
