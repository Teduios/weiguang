//
//  MorePageCollectionViewFlowLayout.h
//  WGForSmile
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MorePageCollectionViewFlowLayout : UICollectionViewFlowLayout

@end
