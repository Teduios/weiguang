//
//  MyCollectViewController.h
//  WGForSmile
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCollectViewController : UIViewController

@end
