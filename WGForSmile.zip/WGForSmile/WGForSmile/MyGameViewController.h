//
//  MyGameViewController.h
//  uiday0405
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyGameViewController : UIViewController

@end
