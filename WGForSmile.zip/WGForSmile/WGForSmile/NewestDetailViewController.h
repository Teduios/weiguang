//
//  NewestDetailViewController.h
//  WGForSmile
//
//  Created by tarena on 15/11/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeNews.h"
@interface NewestDetailViewController : UIViewController
@property (nonatomic,strong) HomeNews * homeNews;
@end
