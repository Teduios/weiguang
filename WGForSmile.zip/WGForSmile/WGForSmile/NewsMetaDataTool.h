//
//  NewsMetaDataTool.h
//  WGForSmile
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsMetaDataTool : NSObject

+(NSArray*)newsFromResult:(id)result;
+(NSArray*)booksChapter:(id)result;
@end
