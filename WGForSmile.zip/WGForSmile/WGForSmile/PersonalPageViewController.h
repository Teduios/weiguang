//
//  PersonalPageViewController.h
//  WGForSmile
//
//  Created by tarena on 15/10/11.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonalPageViewController : UIViewController

@property (nonatomic,strong) UILabel * nickNameLabel;
@property (nonatomic,strong) UIImageView * headimageview;
@property (nonatomic,strong) UIButton* outButton;

@end
