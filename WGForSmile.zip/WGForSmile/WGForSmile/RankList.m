//
//  RankList.m
//  WGForSmile
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "RankList.h"

@implementation RankList

@end
