//
//  RankListDataTool.h
//  WGForSmile
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RankListDataTool : NSObject

+(NSArray *)rankListFromResult:(id)result;

@end
