//
//  Region.h
//  WGForSmile
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Region : NSObject

@property (nonatomic,strong) NSString * name;
@property (nonatomic,strong) NSArray * subregions;

@end
