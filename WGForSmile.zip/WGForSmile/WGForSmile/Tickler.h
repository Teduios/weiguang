//
//  Tickler.h
//  WGForSmile
//
//  Created by tarena on 15/11/9.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tickler : NSObject
@property (nonatomic,strong) NSString * tickler;
@end
