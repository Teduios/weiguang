//
//  Tickler.m
//  WGForSmile
//
//  Created by tarena on 15/11/9.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "Tickler.h"

@implementation Tickler

@end
