//
//  TopRepeatScrollView.h
//  WGForSmile
//
//  Created by tarena on 15/10/16.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TopRepeatScrollView : UIView
@property(nonatomic,strong)NSTimer* timer;
@end
