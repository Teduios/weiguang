//
//  UnderLineTextField.h
//  textfield
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 weiguang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UnderLineTextField : UITextField

@end
